
import numpy as np
import math
import matplotlib.pyplot as plt
from Source_Coding import one_hot_encoder, one_hot_decoder, parity_encoder, parity_decoder
from Hamming_Decoder import hamming_decoder
from Hamming_Encoder import hamming_encoder
from Channel_Modulation import bpsk_modulate, bpsk_demodulate, qpsk_modulate, qpsk_demodulate
from message_to_index import message_to_index, indexr
from AWGN import add_awgn_noise


small_message_set = ["Battery level is critical",
"Object collision detected",
"Robot is overheating",
"Robot is 10 feet from object",
"System malfunction",
"New foreign substance detected",
"Robot has gathered soil sample",
"Abnormal weather detected",
"Collected samples are ready for analyzation",
"Robot has found water source"]

mes = small_message_set[4]
bin = parity_encoder(mes, small_message_set)
print(math.ceil(np.log2(10)))

