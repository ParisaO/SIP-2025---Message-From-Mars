import math
import numpy as np


#####################################################################################
################################## One-Hot ###########################################
# One-hot Encoders
def one_hot_encoder(message=None, message_set=None, index=None, smart=False):
    """
    One-hot encoder with two modes:
    - If smart=False (default): provide message and message_set to encode.
    - If smart=True: provide index and message_set directly (message is ignored).

    Returns:
        np.array: Binary array representation of index.
    """
    if not message_set:
        raise ValueError("message_set must be provided.")

    num_bits = math.ceil(np.log2(len(message_set)))

    if smart:
        if index is None:
            raise ValueError("index must be provided in smart mode.")
    else:
        if message is None:
            raise ValueError("message must be provided in normal mode.")
        if message not in message_set:
            raise ValueError("Message not found in message set.")
        index = message_set.index(message)

    binary = bin(index)[2:].zfill(num_bits)
    return np.array([int(b) for b in binary]), index


def one_hot_decoder(binary_array, message_set, smart):  # This function retruns an index for non-smart one-hot decoder
    binary_str = ''.join(str(int(b)) for b in binary_array)  # Convert binary array from numpy.ndarray to string
    index = int(binary_str, 2)  # Return integer number in decimal scale
    if smart:
        return index
    else:
        if index < len(message_set):
            return message_set[index]
        else:
            # print("Message received corrupted and is out of message set.")
            return None







#####################################################################################
############################### Parity- Check #######################################

def parity_encoder(message=None, message_set=None, index=None, smart=False):
    if not message_set:
        raise ValueError("message_set must be provided.")

    num_messages = len(message_set)
    data_bits = math.ceil(np.log2(num_messages))  # total bits including parity

    if smart:
        if index is None:
            raise ValueError("index must be provided in smart mode.")
        else:
            if message is None:
                raise ValueError("message must be provided in normal mode.")
            if message not in message_set:
                raise ValueError("Message not found in message set.")

    else:  # If it is not a smart system
        index = message_set.index(message)
    binary_num = bin(index)[2:].zfill(data_bits)

    # Add parity bit (even parity)
    parity_bit = '0' if binary_num.count('1') % 2 == 0 else '1'
    binary_num += parity_bit

    print(f"Binary (data + parity): {binary_num}")
    return np.array([int(b) for b in binary_num])

#Parity decodr
def parity_decoder(bits, message_set, smart):
    """
    Decodes a parity-encoded binary message.
    Assumes even parity with one parity bit at the end.
    """
    bits = np.array(bits).astype(int)
    total_length = len(bits)
    if total_length < 2:
        raise ValueError("Invalid bit length for parity decoding.")

    # Separate data and parity bits
    data_bits = bits[:-1]
    parity_bit = bits[-1]

    # Recalculate parity
    calculated_parity = 0 if np.sum(data_bits) % 2 == 0 else 1

    if calculated_parity != parity_bit:
        print("Warning: Parity check failed. Message might be corrupted.")
        return "corrupted"

    # Convert binary array to index
    binary_str = ''.join(str(b) for b in data_bits)
    index = int(binary_str, 2)

    if smart:
        return index
    else:
        if index < len(message_set):
            return message_set[index]
        else:
            # print("Message received corrupted and is out of message set.")
            return None
