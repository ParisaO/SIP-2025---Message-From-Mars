import numpy as np

def add_awgn_noise(symbols, snr_db, mean=0, bits_per_symbol = 1):
    symbols = np.array(symbols)
    linear_snr = 10 ** (snr_db / 10)
    signal_power = np.mean(np.abs(symbols) ** 2)
    k = np.abs(symbols)

    noise_power = signal_power / linear_snr

    if np.iscomplexobj(symbols):
        # Add complex noise (independent noise to real and imag parts)
        noise_std = np.sqrt(noise_power / 2)
        noise_real = np.random.normal(mean, noise_std, symbols.shape)
        noise_imag = np.random.normal(mean, noise_std, symbols.shape)
        noise = noise_real + 1j * noise_imag
    else:
        # Add real noise
        noise_std = np.sqrt(noise_power)
        noise = np.random.normal(mean, noise_std, symbols.shape)

    return symbols + noise


# def add_awgn_noise(symbols, ebn0_db, mean=0, bits_per_symbol=1):
#     symbols = np.array(symbols)
#     # Convert Eb/N0 (input) to Es/N0 based on bits per symbol
#     esn0_db = ebn0_db + 10 * np.log10(bits_per_symbol)
#     linear_esn0 = 10 ** (esn0_db / 10)
#
#     signal_power = np.mean(np.abs(symbols) ** 2)  # Average symbol energy
#     noise_power = signal_power / linear_esn0
#
#     if np.iscomplexobj(symbols):
#         noise_std = np.sqrt(noise_power / 2)
#         noise_real = np.random.normal(mean, noise_std, symbols.shape)
#         noise_imag = np.random.normal(mean, noise_std, symbols.shape)
#         noise = noise_real + 1j * noise_imag
#     else:
#         noise_std = np.sqrt(noise_power)
#         noise = np.random.normal(mean, noise_std, symbols.shape)
#
#     return symbols + noise
