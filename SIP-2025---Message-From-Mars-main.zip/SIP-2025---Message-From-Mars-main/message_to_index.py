def message_to_index(message_set, message):
    binary_space = [format(i, '04b') for i in range(16)]
    
    # Unavailable binary strings
    invalid_codes = {"0001", "0010", "0100", "1011", "1101", "1110"}
    
    code_map = {}
    
    # Assign the emergency messages to '0000' and '1111'
    code_map[message_set[0]] = '0000'
    code_map[message_set[1]] = '1111'
    
    remaining_codes = [code for code in binary_space if code not in invalid_codes and code not in {'0000', '1111'}]

    msg_index = 2  # Start assigning from the third message
    for code in remaining_codes:
        if msg_index < len(message_set):
            code_map[message_set[msg_index]] = code
            msg_index += 1
        else:
            break  

    # Return the binary string for the given message
    return code_map.get(message, "Error: Message not in set")


#binary_str = message_to_index(small_message, "Robot is overheating")
#print(binary_str)  # Output should be '0111'


def indexr(message_set, query, mode):
    """
    Bidirectional index resolver:
    - If query is a message, returns its binary string.
    - If query is a 4-bit binary string, returns the message.
    - Optional 'mode': "encode" or "decode" to force direction.
    """

    binary_space = [format(i, '04b') for i in range(16)]
    invalid_codes = {"0001", "0010", "0100", "1011", "1101", "1110"}

    # Build forward and reverse maps
    msg_to_bin = {}
    bin_to_msg = {}

    # Assign reserved codes
    msg_to_bin[message_set[0]] = '0000'
    msg_to_bin[message_set[1]] = '1111'
    bin_to_msg['0000'] = message_set[0]
    bin_to_msg['1111'] = message_set[1]

    remaining_codes = [code for code in binary_space if code not in invalid_codes and code not in {'0000', '1111'}]

    idx = 2
    for code in remaining_codes:
        if idx < len(message_set):
            msg = message_set[idx]
            msg_to_bin[msg] = code
            bin_to_msg[code] = msg
            idx += 1
        else:
            break

    # Return based on mode
    if mode == "encode":
        return msg_to_bin.get(query, "Error: Message not found in message set.")
    elif mode == "decode":
        return bin_to_msg.get(query, "Error: Binary code not mapped to any message.")
    else:
        raise ValueError("Invalid mode. Use 'encode' or 'decode'.")
